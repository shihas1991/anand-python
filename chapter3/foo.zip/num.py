def square(x):
	return x*x
def cube(x):
	return x*x*x
